import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a02-storing-outgoing',
  templateUrl: './storing-outgoing.component.html',
  styleUrls: ['./storing-outgoing.component.css']
})
export class StoringOutgoingComponent implements OnInit {

  constructor() {}

  ngOnInit() {}
}
