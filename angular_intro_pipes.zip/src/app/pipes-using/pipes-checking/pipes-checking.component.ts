import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a02-pipes-checking',
  templateUrl: './pipes-checking.component.html',
  styleUrls: ['./pipes-checking.component.css']
})
export class PipesCheckingComponent implements OnInit {

  cadena = 'Esto es un literal.';
  numero = 25895.396;
  personas = [
    {
      id: '1',
      nombre: 'Alberto',
      apellidos: 'García Carros'
    },
    {
      id: '2',
      nombre: 'Susana',
      apellidos: 'Montes Gómez'
    },
    {
      id: '3',
      nombre: 'Carmen',
      apellidos: 'Galeote Fernández'
    }
  ];

  constructor() { }

  ngOnInit() {
  }

}
