import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'a02-customer-data',
  templateUrl: './customer-data.component.html',
  styleUrls: ['./customer-data.component.css']
})
export class CustomerDataComponent implements OnInit {

  /* Aquí tenemos toda la lista de clientes, para luego pasar a la vista
  los datos del cliente elegido, si existe el identificador.
  En una aplicación real, no tendríamos aquí esta lista, sino
  que, apartir del identifiacdor, recuperaríamos los datos del
  cliente elegido a través de una API, o recuperaríamos algún
  flag que nos indicara si el id elegido no existe en la base de datos.*/
  private customers_full_list = {
    '108': {
      nombre: 'Pedro',
      apellidos: 'García Cifuentes',
      provincia: 'Barcelona',
      actividad: 'Transporte de Viajeros',
      empresa: 'TRANSGACI, S.A.'
    },
    '227': {
      nombre: 'Ainoa',
      apellidos: 'Etxebarría Koldo',
      provincia: 'Euskadi',
      actividad: 'Manipulación de metales',
      empresa: 'METALIN, S.L.'
    },
    '305': {
      nombre: 'Carmen',
      apellidos: 'González Porras',
      provincia: 'Madrid',
      actividad: 'Relaciones públicas',
      empresa: 'HACIENDO AMIGOS, S.L.'
    },
    '543': {
      nombre: 'Sonia',
      apellidos: 'López Torres',
      provincia: 'Alicante',
      actividad: 'Papelería',
      empresa: 'PAPELERA DE LEVANTE, S.A.U.'
    }
  };

  identifier: any;
  selected_customer: any;

  constructor(private customer: ActivatedRoute) {}

  ngOnInit() {
    this.identifier = this.customer.snapshot.params['id'];
    if (this.customers_full_list[this.identifier] === undefined) {
      this.identifier = '0';
    } else {
      this.selected_customer = this.customers_full_list[this.identifier];
    }
  }
}
