import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a02-customers-list',
  templateUrl: './customers-list.component.html',
  styleUrls: ['./customers-list.component.css']
})
export class CustomersListComponent implements OnInit {

  /* ATENCIÓN. Esta es una matriz que la lógica de negocio va a enviar a la vista.
  En una aplicación real, procedería de una API, u otra fuente dinámica de datos */
  customers_list = [
    {
      id: '108',
      nombre: 'Pedro',
      apellidos: 'García Cifuentes'
    },
    {
      id: '227',
      nombre: 'Ainoa',
      apellidos: 'Etxebarría Koldo'
    },
    {
      id: '305',
      nombre: 'Carmen',
      apellidos: 'González Porras'
    },
    {
      id: '543',
      nombre: 'Sonia',
      apellidos: 'López Torres'
    }
  ];

  constructor() {}

  ngOnInit() {}
}
